
Touch Icons
--------------

Included by default are four touch icon files, which you can edit or
replace if using touch icons (see your theme settings, under Extensions).

The icons are generic and were built using http://appicontemplate.com/

images/touch-icons/default-60x60.png
images/touch-icons/ipad-standard-76x76.png
images/touch-icons/iphone-retina-120x120.png
images/touch-icons/ipad-retina-152x152.png
